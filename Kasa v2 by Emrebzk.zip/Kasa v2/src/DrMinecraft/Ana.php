<?php

namespace DrMinecraft;

use pocketmine\plugin\PluginBase;
use pocketmine\event\{Event, Listener};
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\command\{Command, CommandSender};
use pocketmine\item\Item;
use pocketmine\block\Block;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use onebone\economyapi\EconomyAPI;
use pocketmine\{Player, Server};

class Ana extends PluginBase implements Listener{
	
	public $eco;
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		$this->getLogger()->info("§aKasa Eklenti Aktif §eEmre Bozkurt");
		$this->eco = EconomyAPI::getInstance();
		
	}
	
	public function Kasa(PlayerInteractEvent $e){ 
	$o = $e->getPlayer();
	//demir sandık
	if($e->getBlock()->getId() == Block::CHEST && $e->getBlock()->getSide(0)->getId() == Block::IRON_ORE){
		if($e->getItem()->getId() == Item::GHAST_TEAR){
				$o->getInventory()->removeItem(Item::get(370,0,1));
			$rand = rand(1,20);
			switch($rand){
				case 1:
				$o->getInventory()->addItem(Item::get(133,0,2));
				$o->sendPopUp("§1 2 Adet Zümrüt Blok Çıktı!!");
				break;
				case 2:
				$o->getInventory()->addItem(Item::get(155,0,10));
				$o->sendPopUp("§e10 Adet Kuvars Blok Çıktı!!");
				break;
				case 3:
				$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 4:
				$o->getInventory()->addItem(Item::get(170,0,7));
				$o->sendPopUp("§e7 Adet Saman Blok Çıktı!!");
				break;
				case 5:
				$o->getInventory()->addItem(Item::get(172,0,22));
				$o->sendPopUp("§e22 Adet Sertleştirilmiş Kil Çıktı!!");
				break;
				case 6:
				$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 7:
				$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 8:
				$this->eco->addMoney($o, 200);
				$o->sendPopUp("§6 200 Tl Para Çıktı!!!");
				break;
				case 9:
				$o->getInventory()->addItem(Item::get(278,0,1));
				$o->sendPopUp("§1 1 Adet Elmas Kazma Çıktı!!");
				break;
				case 10:
				$o->getInventory()->addItem(Item::get(279,0,1));
				$o->sendPopUp("§1 1 Adet Elmas Balta Çıktı!!");
				break;
				case 11:
				$o->getInventory()->addItem(Item::get(280,0,9));
				$o->sendPopUp("§e9 Adet Çubuk Çıktı!!");
				break;
				case 12:
				$o->getInventory()->addItem(Item::get(276,0,1));
				$o->sendPopUp("§1 1 Adet Elmas Kılıç Çıktı!!");
				break;
				case 13:
				$o->getInventory()->addItem(Item::get(380,0,1));
				$o->sendPopUp("§e1 Adet Kazan Çıktı!!");
				break;
				case 14:
				$o->getInventory()->addItem(Item::get(355,0,1));
				$o->sendPopUp("§e1 Adet Yatak Çıktı!!");
				break;
				case 15:
				$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 16:
				$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 17:
				$o->getInventory()->addItem(Item::get(350,0,16));
				$o->sendPopUp("§e16 Adet Pişmiş Balık Çıktı!!");
				break;
				case 18:
				$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 19:
				$o->getInventory()->addItem(Item::get(325,10,1));
				$o->sendPopUp("§e1 Adet Lav Kovası Çıktı!!");
				break;
				case 20;
				$o->getInventory()->addItem(Item::get(322,0,4));
				$o->sendPopUp("§c1 4 Adet Altın Elma Çıktı!!!");
			}
		}else{
			$o->sendPopUp("§cYeterli Miktarda Kasa Anahtarın Yok!");
	 	}
 	}
 	//elmas sandık
 	if($e->getBlock()->getId() == Block::CHEST && $e->getBlock()->getSide(0)->getId() == Block::DIAMOND_ORE){
 		if($e->getItem()->getId() == "131"){
 			$o->getInventory()->removeItem(Item::get(421,0,1));
 			$rand = rand(1,20);
 			switch($rand){
 				case 1:
 				$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 2:
				$o->getInventory()->addItem(Item::get(283,0,1));
				$o->getInventory()->addItem(Item::get(284,0,1));
				$o->getInventory()->addItem(Item::get(285,0,1));
				$o->getInventory()->addItem(Item::get(286,0,1));
				$o->getInventory()->addItem(Item::get(294,0,1));
				$o->sendPopUp("§e Altın El Seti Çıktı!!");
				break;
				case 3:
				$o->getInventory()->addItem(Item::get(370,0,1));
				$o->sendPopUp("§1 Ghast Gözyaşı Çıktı!!!");
				break;
				case 4:
				$o->getInventory()->addItem(Item::get(322,0,3));
				$o->sendPopUp("§1 3 Adet Altın Elma Çıktı!!!");
				break;
				case 5:
				$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 6:
				$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 7:
				$o->getInventory()->addItem(Item::get(264,0,3));
				$o->sendPopUp("§1 3 Adet Elmas Çıktı!!");
				break;
				case 8:
					$o->getInventory()->addItem(Item::get(278,0,1));
				$o->sendPopUp("§a1 Adet Elmas Kazma Çıktı!!");
				break;
				case 9:
					$this->eco->addMoney($o->getName, 1000);
				$o->sendPopUp("§6 1000 Tl Para Çıktı!!!");
				break;
				case 10:
					$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 11:
					$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 12:
					$o->getInventory()->addItem(Item::get(322,0,5));
				$o->sendPopUp("§1 5 Adet Altın Elma Çıktı!!!");
				break;
				case 13:
					$o->getInventory()->addItem(Item::get(264,5,1));
				$o->sendPopUp("§a1 3 Adet Elmas Çıktı!!");
				break;
				case 14:
					$o->getInventory()->addItem(Item::get(421,0,1));
				$o->sendPopUp("§a1 Adet İsim Etiketi Çıktı!!!");
				break;
				case 15:
					$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 16:
					$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 17:
					$o->getInventory()->addItem(Item::get(138,0,1));
				$o->sendPopUp("§1 1 Adet Fener Çıktı");
				break;
				case 18:
					$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 19:
					$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
				break;
				case 20:
					$o->getInventory()->addItem(Item::get(0,0,1));
				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
 			}
 		}else{
 			$o->sendPopUp("§cYeterli Miktarda Kasa Anahtarın Yok!");
 		}
 	}
 	//altın sandık
 	if($e->getBlock()->getId() == Block::CHEST && $e->getBlock()->getSide(0)->getId() == Block::GOLD_ORE){
 		if($e->getItem()->getId() == "421"){
 			$o->getInventory()->removeItem(Item::get(131,0,1));
 			$rand = rand(1,20);
 			switch($rand){
 				case 1:
 				$o->getInventory()->addItem(Item::get(266,0,5));
 				$o->sendPopUp("§e5 Adet Altın Külçesi Çıktı!!");
 				break;
 				case 2:
 				$o->getInventory()->addItem(Item::get(283,0,1));
 				$o->getInventory()->addItem(Item::get(284,0,1));
 				$o->getInventory()->addItem(Item::get(285,0,1));
 				$o->getInventory()->addItem(Item::get(286,0,1));
 				$o->getInventory()->addItem(Item::get(294,0,1));
 				$o->sendPopUp("§eAltın El Seti Çıktı!!");
 				break;
 				case 3:
 				$o->getInventory()->addItem(Item::get(388,0,6));
 				$o->sendPopUp("§a6 Adet Zümrüt Çıktı!!!");
 				break;
 				case 4:
 				$o->getInventory()->addItem(Item::get(396,0,9));
 				$o->sendPopUp("§a9 Adet Altın Havuç Çıktı!!!");
 				break;
 				case 5:
 				$o->getInventory()->addItem(Item::get(421,0,1));
 				$o->sendPopUp("§a1 Adet İsim Etiketi Çıktı!!!");
 				break;
 				case 6:
 				$o->getInventory()->addItem(Item::get(0,0,1));
 				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
 				break;
 				case 7:
 				$o->getInventory()->addItem(Item::get(397,0,1));
 				$o->sendPopUp("§a1 Adet İskelet Kafası Çıktı!!");
 				break;
 				case 8:
 				$o->getInventory()->addItem(Item::get(384,0,22));
 				$o->sendPopUp("§e22 Adet Büyü Şişesi Çıktı!!");
 				break;
 				case 9:
 			$o->getInventory()->addItem(Item::get(0,0,1));
 				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
 				break;
 				case 10:
 				$o->getInventory()->addItem(Item::get(322,0,3));
 				$o->sendPopUp("§a3 Adet Altın Elma Çıktı!!!");
 				break;
 				case 11:
 				$o->getInventory()->addItem(Item::get(41,0,2));
 				$o->sendPopUp("§a2 Adet Altın Blok Çıktı!!");
 				break;
 				case 12:
 				$o->getInventory()->addItem(Item::get(47,0,6));
 				$o->sendPopUp("§e6 Adet Kitaplık Çıktı!!");
 				break;
 				case 13:
 				$o->getInventory()->addItem(Item::get(50,0,39));
 				$o->sendPopUp("§e39 Adet Meşale Çıktı!!");
 				break;
 				case 14:
 				$o->getInventory()->addItem(Item::get(86,0,9));
 				$o->sendPopUp("§e9 Adet Balkabağı Çıktı!!");
 				break;
 				case 15:
 				$o->getInventory()->addItem(Item::get(98,0,18));
 				$o->sendPopUp("§e18 Adet Taş Tugla Çıktı!!");
 				break;
 				case 16:
 				$o->getInventory()->addItem(Item::get(118,0,1));
 				$o->sendPopUp("§e1 Adet Kazan Çıktı!!");
 				break;
 				case 17:
 				$o->getInventory()->addItem(Item::get(0,0,1));
 				$o->sendPopUp("§cTüh! Çok Şansızsın Boş Çıktı!!");
 				break;
 				case 18:
 				$o->getInventory()->addItem(Item::get(154,0,5));
 				$o->sendPopUp("§a5 Adet Huni Çıktı!!!");
 				break;
 				case 19:
 				$o->getInventory()->addItem(Item::get(278,0,1));
 				$o->sendPopUp("§a1 Adet Elmas Kazma Çıktı!!!");
 				break;
 				case 20:
 				$o->getInventory()->addItem(Item::get(352,0,16));
 				$o->sendPopUp("§e16 Adet Kemik Çıktı!!");
 				break;
 			}
 		}else{
 			$o->sendPopUp("§cYeterli Miktarda Kasa Anahtarın Yok!");
 		}
 	}
	}
	public function onCommand(CommandSender $g, Command $k, $label, array $args){
		if($k->getName() == "kasa"){
			$g->sendMessage("§eKullanımı: \n §6Elmas Kasa: §fdiamınd ore block'unu alta koyuyoruz üzerine chest koydugunuz zaman  elmas hazır \n §6Anahtarın Id: §f131");
			$g->sendMessage("§eKullanımı: \n §6Altın Kasa: §fgold ore block'unu alta koyuyoruz üzerine chest koydugunuz zaman altın kasa hazır \n §6Anahtarın Id: §f421");
			$g->sendMessage("§eKullanımı: \n §6Demir Kasa: §fIron ore block'unu alta koyuyoruz üzerine chest koydugunuz zaman demir kasa hazır \n §6Anahtarın Id: §f370");
			$g->sendMessage("§cPlugini Yapan Kişi: §fEmre Bozkurt");
			$g->sendMessage("§cYou§fTube: §6DrMinecraft");
		}
	}
}