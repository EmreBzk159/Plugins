<?php

namespace EmreBzk;

use pocketmine\plugin\PluginBase;
use pocketmine\command\{CommandSender, Command};
use pocketmine\entity\Effect;
use pocketmine\Player;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("§e Eklenti Hazır §aBy Emre Bozkurt");
	}
	
	public function onCommand(CommandSender $g, Command $k, string $label, array $args){
		if($k->getName() == "madenci"){
			
			if(strtolower($args[0] == "yardım")){
				$g->sendMessage("§6--§f{{§aMadenci Modu Yardım Sayfası§f}}§6--");
				$g->sendMessage("§f» /madencimodu ac : §6 Madenci Modunu Açar");
				$g->sendMessage("§f» /madencimodu kapat : §6 Madenci Modunu Kapatır");
				$g->sendMessage("§2» Eklentiyi Yapan Kişi §cEmre Bozkurt");
				
				}//Strtolower Yardım
				
				if(strtolower($args[0] == "ac")){
					$eff = Effect::getEffect(3);
					$eff->setAmplifier(3);
					$eff->setVisible(true);
					$eff->setDuration(999999);
					$g->addEffect($eff);
					
					
					$ef = Effect::getEffect(16);
					$ef->setAmplifier(3);
					$ef->setVisible(true);
					$ef->setDuration(999999);
					$g->addEffect($ef);
					
					$g->sendMessage("§e» Madenci Modu Aktif.");
					
					}//Strtolower Ac
					
					if(strtolower($args[0] == "kapat")){
						$o = $g->getPlayer();
						
						$o->removeAllEffects();
						$o->sendMessage("§e» Madenci Modu Kapatıldı.");
						
			}//strtolower Kapat
		}//Komut
	}//onCommand
}//PluginBase